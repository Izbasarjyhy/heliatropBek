package com.izba.music.springapp1.MusicPlayer;

public interface Music {
    public String getSong();
}