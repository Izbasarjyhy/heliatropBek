package com.izba.music.springapp1.aspect;


import com.izba.music.springapp1.entity.MyLogger;
import com.izba.music.springapp1.service.MyLoggerService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.stream.Collectors;

@Aspect
@Component
@Slf4j
@RequiredArgsConstructor
public class MyLoggerAspect {
    private final MyLoggerService myLoggerService;


    @Around(value ="@annotation(com.izba.music.springapp1.aspect.ToLogOurApp)")
    public Object myLogMethod(ProceedingJoinPoint joinPoint) throws Throwable {

        log.info("Hi my logger");
        String answer = (String) joinPoint.proceed();

        String request= Arrays.stream(joinPoint.getArgs()).map(Object::toString).collect(Collectors.joining());

        MyLogger newLog=new MyLogger(null,request,answer, LocalDateTime.now());


        myLoggerService.log(newLog);

        log.info("in->{}, out->{}",request,answer);


        return answer;
    }
}
