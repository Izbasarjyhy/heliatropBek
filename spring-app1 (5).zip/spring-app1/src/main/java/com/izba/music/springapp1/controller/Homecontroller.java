package com.izba.music.springapp1.controller;


import org.springframework.ui.Model;
import com.izba.music.springapp1.aspect.ToLogOurApp;
import com.izba.music.springapp1.dto.CategoryDto;
import com.izba.music.springapp1.dto.MusicDto;
import com.izba.music.springapp1.entity.Category;
import com.izba.music.springapp1.entity.Musics;
import com.izba.music.springapp1.entity.User;
import com.izba.music.springapp1.service.CategoryService;
import com.izba.music.springapp1.service.MusicService;
import com.izba.music.springapp1.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import java.util.List;
import java.util.Optional;

@ToLogOurApp
@RestController
@RequestMapping("/home")
public class Homecontroller{
    private final UserService userService;
    private final CategoryService categoryService;
    private  final MusicService musicService;

    public Homecontroller(UserService userService,MusicService musicService,CategoryService categoryService) {
        this.userService = userService;
        this.musicService= musicService;
        this.categoryService=categoryService;
    }



    @PostMapping("/User")
    public String addUser(@RequestBody User user){
        return userService.addUser(user);
    }

    @GetMapping("/User")
    public List<User> getAllUsers(){
        return userService.getAllUsers();
    }

    @PostMapping("/music")
    @ToLogOurApp
    public String addMusic(@RequestBody MusicDto musicDto){
       return musicService.addMusic(musicDto);
    }

    @GetMapping("/music")
    public List<Musics> getAllMusic(){
        return musicService.getAllMusic();
    }



    @PostMapping("/Category")
    public String addCategory(@RequestBody CategoryDto categoryDto){

        return categoryService.addCategory(categoryDto);
    }
    @GetMapping("/Category")
    public List<Category> getAllCategory(){
        return categoryService.getAllCategory();
    }

   @GetMapping ("/registor")
   public ModelAndView registor() {
       ModelAndView modelAndView = new ModelAndView();
       modelAndView.setViewName("registor.html");
       return modelAndView;
   }
    @GetMapping ("/profil/{id}")
    public ModelAndView profil(@PathVariable Long id) {
        ModelAndView modelAndView = new ModelAndView();
        Optional<User> user = userService.getUserById(id);

        if (user.isPresent()) {
            modelAndView.addObject("user", user.get());
            modelAndView.setViewName("profil.html");
        } else {
            modelAndView.setViewName("user-not-found.html");
        }
        return modelAndView;

    }

    @GetMapping("/users/{id}")
    public ModelAndView getUserById(@PathVariable Long id) {
        ModelAndView modelAndView = new ModelAndView();
        Optional<User> user = userService.getUserById(id);
        if (user.isPresent()) {
            modelAndView.addObject("user", user.get());
            modelAndView.setViewName("user-details.html");
        } else {
            modelAndView.setViewName("user-not-found.html");
        }
        return modelAndView;
    }






}
