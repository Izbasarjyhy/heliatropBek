package com.izba.music.springapp1.dto;

public class CategoryDto {
    private Long id;
    private String name;
    public CategoryDto(){

    }

    public CategoryDto(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }



}
