package com.izba.music.springapp1.dto;

import com.izba.music.springapp1.aspect.ToLogOurApp;
import lombok.ToString;

@ToString
public class MusicDto {
    private String name;
    private Long category;

    public MusicDto() {
    }


    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }


    public Long getCategory() {
        return category;
    }


    public void setCategory(Long category) {
        this.category = category;
    }




}
