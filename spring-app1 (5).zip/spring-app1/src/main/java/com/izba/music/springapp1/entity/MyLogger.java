package com.izba.music.springapp1.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "my_logger")
public class MyLogger {



    @Id
    @GeneratedValue
    @Column(name = "id")
    private Long id;

    private String request;
    private String response;
    private LocalDateTime createdAt;

}
