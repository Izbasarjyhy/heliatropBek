package com.izba.music.springapp1.repozitory;

import com.izba.music.springapp1.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface  CategoryRepozitory extends JpaRepository<Category,Long> {
//    public List<User> findUsersByNameContainsIgnoreCase(String name);
}
