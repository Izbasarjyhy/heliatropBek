package com.izba.music.springapp1.repozitory;

import com.izba.music.springapp1.entity.MyLogger;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LoggerRepository extends JpaRepository<MyLogger,Long> {
}
