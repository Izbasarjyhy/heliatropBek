package com.izba.music.springapp1.repozitory;


import com.izba.music.springapp1.entity.Musics;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MusicRepository extends JpaRepository<Musics,Long> {
//    public List<User> findUsersByNameContainsIgnoreCase(String name);
}
