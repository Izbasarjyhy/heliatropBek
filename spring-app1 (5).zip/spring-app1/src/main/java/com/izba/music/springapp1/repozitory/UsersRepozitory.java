package com.izba.music.springapp1.repozitory;

import com.izba.music.springapp1.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UsersRepozitory extends JpaRepository<User,Long> {
//    public List<User> findUsersByNameContainsIgnoreCase(String name);
}
