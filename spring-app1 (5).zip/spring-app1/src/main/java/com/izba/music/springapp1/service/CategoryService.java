package com.izba.music.springapp1.service;

import com.izba.music.springapp1.dto.CategoryDto;
import com.izba.music.springapp1.entity.Category;
import com.izba.music.springapp1.repozitory.CategoryRepozitory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryService {
    private final CategoryRepozitory repozitory;

    public CategoryService(CategoryRepozitory repozitory) {
        this.repozitory = repozitory;
    }

    public String addCategory(CategoryDto dto){
        try {
            Category category=new Category();
            category.setName(dto.getName());
            repozitory.save(category);

        }catch (Exception e){
            return "Kosylmady"+e.getMessage();
        }
        return "Kosyldy";
    }
    public List<Category> getAllCategory(){
        return repozitory.findAll();
    }
    public Category getCategoryById(Long id) {
        return repozitory.getById(id);
    }
}
