package com.izba.music.springapp1.service;

import com.izba.music.springapp1.dto.MusicDto;
import com.izba.music.springapp1.entity.Category;
import com.izba.music.springapp1.entity.Musics;
import com.izba.music.springapp1.repozitory.MusicRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MusicService{
    private final MusicRepository repozitory;
    private CategoryService categoryService;

    public MusicService(MusicRepository repozitory, CategoryService categoryService) {
        this.repozitory = repozitory;
        this.categoryService = categoryService;
    }

    public String addMusic(MusicDto dto){
        if(!dto.getName().isBlank() ) {
            Musics music = new Musics();

            music.setName(dto.getName());
            Category category = categoryService.getCategoryById(dto.getCategory());
            music.setCategory(category);

            repozitory.save(music);
        }
        return "Kosyldy";
    }

    public List<Musics> getAllMusic(){
        return repozitory.findAll();
    }

}
