package com.izba.music.springapp1.service;

import com.izba.music.springapp1.entity.MyLogger;
import com.izba.music.springapp1.repozitory.LoggerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
@RequiredArgsConstructor
@Service
public class MyLoggerService {
    private final LoggerRepository loggerRepository;

    public MyLogger log(MyLogger log){
        return loggerRepository.save(log);
    }
}