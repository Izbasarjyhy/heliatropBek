package com.izba.music.springapp1.service;
import com.izba.music.springapp1.entity.User;

import com.izba.music.springapp1.repozitory.UsersRepozitory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    private final UsersRepozitory repozitory;

    public UserService(UsersRepozitory repozitory) {
        this.repozitory = repozitory;
    }

    public String addUser(User user) {
        if (user != null &&
                user.getLastName() != null &&
                !user.getLastName().isBlank() &&
                user.getFirstName() != null &&
                !user.getFirstName().isBlank() &&
                user.getEmail() != null &&
                !user.getEmail().isBlank() &&
                user.getPassword() != null ) {
            repozitory.save(user);
            return "Kosyldy";
        } else {
            return "Ошибка: Поля пользователя не могут быть пустыми или null";
        }
    }


    public List<User> getAllUsers() {
        return repozitory.findAll();
    }

    public Optional<User> getUserById(Long id) {
        return repozitory.findById(id);
    }
}
